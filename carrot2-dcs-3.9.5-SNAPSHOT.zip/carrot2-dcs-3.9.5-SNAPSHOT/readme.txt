Carrot2 Document Clustering Server
----------------------------------

Carrot2 Document Clustering Server exposes Carrot2 clustering as a REST
service. It can cluster documents from an external source  (e.g., a search
engine) or documents provided directly as an XML stream. Results are returned
in XML or JSON formats. 

The DCS requires a Java Runtime Environment (JRE) version 1.6.0 or later. To
run the DCS, execute the 'dcs' script and point your browser at
http://localhost:8080 for further instructions.

For more information, please refer to Carrot2 Manual:
http://download.carrot2.org/stable/manual



Build information
-----------------

Build version : 3.9.5-SNAPSHOT
Build number  : C2-SOFTWARE1-DCS-34
Build time    : 2014-11-25 15:00:19
Built by      : bamboo
Build revision: 60562cb4f7b0d9002d1bbf77f91ac4b0845caebb
